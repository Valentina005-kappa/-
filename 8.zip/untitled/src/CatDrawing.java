import javax.swing.*;
import javax.swing.*;
import java.awt.*;

public class CatDrawing extends JPanel {

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        g2d.drawOval(150, 50, 100, 100);
        g2d.fillOval(170, 75, 20, 20);
        g2d.fillOval(210, 75, 20, 20);
        g2d.drawOval(195, 90, 10, 10);
        g2d.drawLine(200, 100, 200, 120);

        g2d.drawLine(200, 110, 250, 100);
        g2d.drawLine(200, 110, 250, 110);
        g2d.drawLine(200, 110, 250, 120);

        g2d.drawLine(150, 100, 200, 110);
        g2d.drawLine(150, 110, 200, 110);
        g2d.drawLine(150, 120, 200, 110);

        g2d.drawOval(125, 150, 150, 150);
        g2d.fillOval(165, 190, 70, 70);

        g2d.drawLine(100, 250, 150, 230);
        g2d.drawLine(100, 250, 110, 280);
        g2d.drawLine(110, 280, 150, 230);

        g2d.drawLine(150, 50, 170, 20);
        g2d.drawLine(170, 20, 190, 50);

        g2d.drawLine(210, 50, 230, 20);
        g2d.drawLine(230, 20, 250, 50);

        g2d.drawLine(180, 300, 160, 330);
        g2d.drawLine(220, 300, 240, 330);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Cat Drawing");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 400);
        frame.add(new CatDrawing());
        frame.setVisible(true);
    }
}
