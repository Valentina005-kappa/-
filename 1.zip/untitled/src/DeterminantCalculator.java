public class DeterminantCalculator {

    public static double determinant(double[][] matrix) {
        int n = matrix.length;

        if (n == 1) {
            return matrix[0][0];
        }

        if (n == 2) {
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        }

        double det = 0;
        for (int col = 0; col < n; col++) {
            // Получаем минор путем исключения текущей строки и столбца
            double[][] minor = getMinor(matrix, 0, col);
            // Рекурсивное вычисление определителя для минора
            det += Math.pow(-1, col) * matrix[0][col] * determinant(minor);
        }

        return det;
    }

    private static double[][] getMinor(double[][] matrix, int row, int col) {
        int n = matrix.length;
        double[][] minor = new double[n - 1][n - 1];

        int minorRow = 0;
        int minorCol;
        for (int i = 0; i < n; i++) {
            if (i == row) continue; // пропускаем указанную строку
            minorCol = 0;
            for (int j = 0; j < n; j++) {
                if (j == col) continue; // пропускаем указанный столбец
                minor[minorRow][minorCol] = matrix[i][j];
                minorCol++;
            }
            minorRow++;
        }
        return minor;
    }

    public static void main(String[] args) {
        double[][] matrix = {
                {6, 1, 1},
                {4, -2, 5},
                {2, 8, 7}
        };

        double det = determinant(matrix);
        System.out.println("Определитель матрицы: " + det);
    }
}
