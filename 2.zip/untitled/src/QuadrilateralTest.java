import java.util.*;
abstract class Quadrilateral {
    protected double x1, y1, x2, y2, x3, y3, x4, y4;

    public Quadrilateral(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
        this.x1 = x1; this.y1 = y1;
        this.x2 = x2; this.y2 = y2;
        this.x3 = x3; this.y3 = y3;
        this.x4 = x4; this.y4 = y4;
    }

    public abstract double getArea();
    public abstract double getPerimeter();

    protected double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));
    }
}

class GeneralQuadrilateral extends Quadrilateral {

    public GeneralQuadrilateral(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
        super(x1, y1, x2, y2, x3, y3, x4, y4);
    }

    @Override
    public double getArea() {
        return 0.5 * Math.abs(x1*y2 + x2*y3 + x3*y4 + x4*y1 - y1*x2 - y2*x3 - y3*x4 - y4*x1);
    }

    @Override
    public double getPerimeter() {
        return distance(x1, y1, x2, y2) + distance(x2, y2, x3, y3) + distance(x3, y3, x4, y4) + distance(x4, y4, x1, y1);
    }
}

class Rectangle extends GeneralQuadrilateral {

    public Rectangle(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
        super(x1, y1, x2, y2, x3, y3, x4, y4);
    }

    @Override
    public double getArea() {
        double length = distance(x1, y1, x2, y2);
        double width = distance(x2, y2, x3, y3);
        return length * width;
    }

    @Override
    public double getPerimeter() {
        double length = distance(x1, y1, x2, y2);
        double width = distance(x2, y2, x3, y3);
        return 2 * (length + width);
    }
}

class Square extends Rectangle {

    public Square(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
        super(x1, y1, x2, y2, x3, y3, x4, y4);
    }

    @Override
    public double getArea() {
        double side = distance(x1, y1, x2, y2);
        return side * side;
    }

    @Override
    public double getPerimeter() {
        double side = distance(x1, y1, x2, y2);
        return 4 * side;
    }
}

class Rhombus extends GeneralQuadrilateral {

    public Rhombus(double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4) {
        super(x1, y1, x2, y2, x3, y3, x4, y4);
    }

    @Override
    public double getArea() {
        double d1 = distance(x1, y1, x3, y3);
        double d2 = distance(x2, y2, x4, y4);
        return (d1 * d2) / 2;
    }

    @Override
    public double getPerimeter() {
        double side = distance(x1, y1, x2, y2);
        return 4 * side;
    }
}

public class QuadrilateralTest {
    public static void main(String[] args) {
        List<Quadrilateral> quadrilaterals = new ArrayList<>();
        quadrilaterals.add(new Square(0, 0, 0, 2, 2, 2, 2, 0));
        quadrilaterals.add(new Rectangle(0, 0, 0, 3, 4, 3, 4, 0));
        quadrilaterals.add(new Rhombus(0, 0, 1, 2, 2, 0, 1, -2));
        quadrilaterals.add(new GeneralQuadrilateral(0, 0, 1, 3, 4, 3, 3, 0));

        Map<String, List<Quadrilateral>> groups = new HashMap<>();
        groups.put("Square", new ArrayList<>());
        groups.put("Rectangle", new ArrayList<>());
        groups.put("Rhombus", new ArrayList<>());
        groups.put("General", new ArrayList<>());

        for (Quadrilateral q : quadrilaterals) {
            if (q instanceof Square) {
                groups.get("Square").add(q);
            } else if (q instanceof Rectangle) {
                groups.get("Rectangle").add(q);
            } else if (q instanceof Rhombus) {
                groups.get("Rhombus").add(q);
            } else if (q instanceof GeneralQuadrilateral) {
                groups.get("General").add(q);
            }
        }

        for (String type : groups.keySet()) {
            List<Quadrilateral> list = groups.get(type);
            if (list.isEmpty()) continue;

            Quadrilateral maxArea = Collections.max(list, Comparator.comparingDouble(Quadrilateral::getArea));
            Quadrilateral minArea = Collections.min(list, Comparator.comparingDouble(Quadrilateral::getArea));
            Quadrilateral maxPerimeter = Collections.max(list, Comparator.comparingDouble(Quadrilateral::getPerimeter));
            Quadrilateral minPerimeter = Collections.min(list, Comparator.comparingDouble(Quadrilateral::getPerimeter));

            System.out.println(type + ": ");
            System.out.println("Наибольшая площадь: " + maxArea.getArea());
            System.out.println("Наименьшая площадь: " + minArea.getArea());
            System.out.println("Наибольший периметр: " + maxPerimeter.getPerimeter());
            System.out.println("Наименьший периметр: " + minPerimeter.getPerimeter());
            System.out.println();
        }
    }
}
