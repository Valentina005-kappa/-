public class PyramidSection {
    public static void main(String[] args) {
        double a = 10;
        double h = 15;
        double angle = 30;

        double[] A = {0, 0, 0};
        double[] C = {a, a, 0};
        double[] S = {a / 2, a / 2, h};

        double k = findK(angle, a, h);

        double[] M = {a, k * a / 2, k * h};

        double[] normalVector = crossProduct(
                new double[]{C[0] - A[0], C[1] - A[1], C[2] - A[2]},
                new double[]{M[0] - A[0], M[1] - A[1], M[2] - A[2]}
        );

        double D = -(normalVector[0] * A[0] + normalVector[1] * A[1] + normalVector[2] * A[2]);
        System.out.printf("Уравнение плоскости: %.2fx + %.2fy + %.2fz + %.2f = 0%n",
                normalVector[0], normalVector[1], normalVector[2], D);
    }

    private static double findK(double angle, double a, double h) {
        double radianAngle = Math.toRadians(angle);
        return Math.tan(radianAngle) * a / (2 * h);
    }

    private static double[] crossProduct(double[] v1, double[] v2) {
        return new double[]{
                v1[1] * v2[2] - v1[2] * v2[1],
                v1[2] * v2[0] - v1[0] * v2[2],
                v1[0] * v2[1] - v1[1] * v2[0]
        };
    }
}
