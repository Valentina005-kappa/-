import java.util.ArrayList;
import java.util.List;

public class City {

    private String name;
    private List<Street> streets;
    private List<Avenue> avenues;
    private List<Square> squares;

    public City(String name) {
        this.name = name;
        this.streets = new ArrayList<>();
        this.avenues = new ArrayList<>();
        this.squares = new ArrayList<>();
    }

    public void addStreet(String name, double length) {
        this.streets.add(new Street(name, length));
    }

    public void addAvenue(String name, double length) {
        this.avenues.add(new Avenue(name, length));
    }

    public void addSquare(String name, double area) {
        this.squares.add(new Square(name, area));
    }

    public void showInfo() {
        System.out.println("Город: " + name);
        System.out.println("Улицы:");
        for (Street street : streets) {
            System.out.println(street);
        }

        System.out.println("Проспекты:");
        for (Avenue avenue : avenues) {
            System.out.println(avenue);
        }

        System.out.println("Площади:");
        for (Square square : squares) {
            System.out.println(square);
        }
    }

    public class Street {
        private String name;
        private double length;

        public Street(String name, double length) {
            this.name = name;
            this.length = length;
        }

        @Override
        public String toString() {
            return "Улица: " + name + ", длина: " + length + " км";
        }
    }

    public class Avenue {
        private String name;
        private double length;

        public Avenue(String name, double length) {
            this.name = name;
            this.length = length;
        }

        @Override
        public String toString() {
            return "Проспект: " + name + ", длина: " + length + " км";
        }
    }

    public class Square {
        private String name;
        private double area;

        public Square(String name, double area) {
            this.name = name;
            this.area = area;
        }

        @Override
        public String toString() {
            return "Площадь: " + name + ", площадь: " + area + " кв. км";
        }
    }

    public static void main(String[] args) {
        City city = new City("Москва");

        city.addStreet("Тверская улица", 2.5);
        city.addAvenue("Проспект Мира", 8.6);
        city.addSquare("Красная площадь", 0.23);

        city.showInfo();
    }
}
