import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

class Symbol {
    private char character;

    public Symbol(char character) {
        this.character = character;
    }

    public char getCharacter() {
        return character;
    }

    public boolean isVowel() {
        return "AEIOUYaeiouyАЕЁИОУЫЭЮЯаеёиоуыэюя".indexOf(character) != -1;
    }

    public boolean isConsonant() {
        return "BCDFGHJKLMNPQRSTVWXZbcdfghjklmnpqrstvwxzБВГДЖЗЙКЛМНПРСТФХЦЧШЩбвгджзйклмнпрстфхцчшщ".indexOf(character) != -1;
    }

    @Override
    public String toString() {
        return Character.toString(character);
    }
}

class Word {
    private List<Symbol> symbols;

    public Word(String word) {
        symbols = new ArrayList<>();
        for (char c : word.toCharArray()) {
            symbols.add(new Symbol(c));
        }
    }

    public boolean startsWithVowel() {
        return !symbols.isEmpty() && symbols.get(0).isVowel();
    }

    public char getFirstConsonant() {
        for (Symbol symbol : symbols) {
            if (symbol.isConsonant()) {
                return symbol.getCharacter();
            }
        }
        return '\0';
    }

    @Override
    public String toString() {
        return symbols.stream().map(Symbol::toString).collect(Collectors.joining());
    }
}

class Sentence {
    private List<Word> words;

    public Sentence(String sentence) {
        words = new ArrayList<>();
        String[] wordArray = sentence.split("\\s+");
        for (String word : wordArray) {
            words.add(new Word(word));
        }
    }

    public List<Word> getWordsStartingWithVowel() {
        return words.stream().filter(Word::startsWithVowel).collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return words.stream().map(Word::toString).collect(Collectors.joining(" "));
    }
}

class Paragraph {
    private List<Sentence> sentences;

    public Paragraph(String paragraph) {
        sentences = new ArrayList<>();
        String[] sentenceArray = paragraph.split("(?<=[.!?])\\s*");
        for (String sentence : sentenceArray) {
            sentences.add(new Sentence(sentence));
        }
    }

    public List<Word> getWordsStartingWithVowel() {
        List<Word> vowelWords = new ArrayList<>();
        for (Sentence sentence : sentences) {
            vowelWords.addAll(sentence.getWordsStartingWithVowel());
        }
        return vowelWords;
    }

    @Override
    public String toString() {
        return sentences.stream().map(Sentence::toString).collect(Collectors.joining(" "));
    }
}

class Text {
    private List<Paragraph> paragraphs;

    public Text(String text) {
        paragraphs = new ArrayList<>();
        String[] paragraphArray = text.split("\\n+");
        for (String paragraph : paragraphArray) {
            paragraphs.add(new Paragraph(paragraph.trim().replaceAll("\\s+", " ")));
        }
    }

    public List<Word> getWordsStartingWithVowel() {
        List<Word> vowelWords = new ArrayList<>();
        for (Paragraph paragraph : paragraphs) {
            vowelWords.addAll(paragraph.getWordsStartingWithVowel());
        }
        return vowelWords;
    }

    @Override
    public String toString() {
        return paragraphs.stream().map(Paragraph::toString).collect(Collectors.joining("\n"));
    }
}

public class TextProcessor {
    public static void main(String[] args) {
        String text = "Это пример текста. Он состоит из нескольких предложений. Абзац начинается с гласной буквы.\n"
                + "Вот еще один абзац для тестирования программы. У этого абзаца тоже есть гласные.";

        Text textObj = new Text(text);

        List<Word> vowelWords = textObj.getWordsStartingWithVowel();

        vowelWords.sort((w1, w2) -> {
            char consonant1 = w1.getFirstConsonant();
            char consonant2 = w2.getFirstConsonant();
            return Character.compare(consonant1, consonant2);
        });

        System.out.println("Слова, начинающиеся с гласных, отсортированные по первой согласной:");
        for (Word word : vowelWords) {
            System.out.println(word);
        }
    }
}
