import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

abstract class RailwayTransport {
    protected int passengerCount;
    protected int luggageCount;

    public RailwayTransport(int passengerCount, int luggageCount) {
        this.passengerCount = passengerCount;
        this.luggageCount = luggageCount;
    }

    public int getPassengerCount() {
        return passengerCount;
    }

    public int getLuggageCount() {
        return luggageCount;
    }

    public abstract int getComfortLevel();
}

class PassengerCar extends RailwayTransport {
    private int comfortLevel; // Уровень комфортности (1-люкс, 2-купе, 3-плацкарт и т.д.)

    public PassengerCar(int passengerCount, int luggageCount, int comfortLevel) {
        super(passengerCount, luggageCount);
        this.comfortLevel = comfortLevel;
    }

    @Override
    public int getComfortLevel() {
        return comfortLevel;
    }

    @Override
    public String toString() {
        return "PassengerCar{" +
                "passengerCount=" + passengerCount +
                ", luggageCount=" + luggageCount +
                ", comfortLevel=" + comfortLevel +
                '}';
    }
}

class Train {
    private List<PassengerCar> cars;

    public Train() {
        cars = new ArrayList<>();
    }

    public void addCar(PassengerCar car) {
        cars.add(car);
    }

    public int getTotalPassengers() {
        return cars.stream().mapToInt(PassengerCar::getPassengerCount).sum();
    }

    public int getTotalLuggage() {
        return cars.stream().mapToInt(PassengerCar::getLuggageCount).sum();
    }

    public void sortCarsByComfort() {
        cars.sort(Comparator.comparingInt(PassengerCar::getComfortLevel));
    }

    public List<PassengerCar> findCarsByPassengerRange(int minPassengers, int maxPassengers) {
        List<PassengerCar> result = new ArrayList<>();
        for (PassengerCar car : cars) {
            if (car.getPassengerCount() >= minPassengers && car.getPassengerCount() <= maxPassengers) {
                result.add(car);
            }
        }
        return result;
    }

    public void displayCars() {
        for (PassengerCar car : cars) {
            System.out.println(car);
        }
    }
}

public class RailwayApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Train train = new Train();

        train.addCar(new PassengerCar(50, 100, 1));
        train.addCar(new PassengerCar(40, 80, 2));
        train.addCar(new PassengerCar(60, 120, 3));
        train.addCar(new PassengerCar(55, 90, 2));
        train.addCar(new PassengerCar(70, 140, 3));

        while (true) {
            System.out.println("Меню:");
            System.out.println("1. Показать вагоны");
            System.out.println("2. Подсчитать общую численность пассажиров и багажа");
            System.out.println("3. Сортировать вагоны по уровню комфортности");
            System.out.println("4. Найти вагоны по диапазону пассажиров");
            System.out.println("5. Выход");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    train.displayCars();
                    break;
                case 2:
                    System.out.println("Общее количество пассажиров: " + train.getTotalPassengers());
                    System.out.println("Общее количество багажа: " + train.getTotalLuggage());
                    break;
                case 3:
                    train.sortCarsByComfort();
                    System.out.println("Вагоны отсортированы по уровню комфортности.");
                    break;
                case 4:
                    System.out.println("Введите минимальное количество пассажиров:");
                    int minPassengers = scanner.nextInt();
                    System.out.println("Введите максимальное количество пассажиров:");
                    int maxPassengers = scanner.nextInt();
                    List<PassengerCar> foundCars = train.findCarsByPassengerRange(minPassengers, maxPassengers);
                    if (foundCars.isEmpty()) {
                        System.out.println("Вагоны не найдены.");
                    } else {
                        for (PassengerCar car : foundCars) {
                            System.out.println(car);
                        }
                    }
                    break;
                case 5:
                    System.out.println("Выход из программы.");
                    return;
                default:
                    System.out.println("Неверный выбор. Попробуйте снова.");
            }
        }
    }
}
