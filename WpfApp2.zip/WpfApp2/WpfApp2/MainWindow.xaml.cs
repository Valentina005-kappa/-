﻿using System;
using System.Data;
using System.Data.SQLite;
using System.Windows;
using System.Windows.Controls;

namespace AISDatabaseApp
{
    public partial class MainWindow : Window
    {
        string connectionString = "Data Source=mydatabase.db;Version=3;";

        public MainWindow()
        {
            InitializeComponent();
            LoadData(); 
        }
        private void ExecuteNonQuery(SQLiteConnection connection, string commandText)
        {
            using (var command = new SQLiteCommand(commandText, connection))
            {
                command.ExecuteNonQuery();
            }
        }
        private void LoadData()
        {
            using (var connection = new SQLiteConnection(connectionString))
            {
                connection.Open();
                LoadDataIntoGrid(connection);
                connection.Close();
            }
        }
        private void LoadDataIntoGrid(SQLiteConnection connection)
        {
            LoadTableData(connection, "SELECT * FROM Customer", dataGridCustomers);
            LoadTableData(connection, "SELECT * FROM Category", dataGridCategories);
            LoadTableData(connection, "SELECT * FROM Supplier", dataGridSuppliers);
            LoadTableData(connection, "SELECT * FROM `Order`", dataGridOrders);
            LoadTableData(connection, "SELECT * FROM Product", dataGridProducts);
        }
        private void LoadTableData(SQLiteConnection connection, string query, DataGrid dataGrid)
        {
            using (var command = new SQLiteCommand(query, connection))
            using (var reader = command.ExecuteReader())
            {
                var dataTable = new DataTable();
                dataTable.Load(reader);
                dataGrid.ItemsSource = dataTable.DefaultView;
            }
        }
                private void AddCustomerButton_Click(object sender, RoutedEventArgs e)
                {
                    CustomerExpander.IsExpanded = true;
                }
                private void SaveCustomerButton_Click(object sender, RoutedEventArgs e)
                {
                    if (string.IsNullOrWhiteSpace(CustomerNameTextBox.Text) ||
                        string.IsNullOrWhiteSpace(CustomerAddressTextBox.Text) ||
                        string.IsNullOrWhiteSpace(CustomerContactInfoTextBox.Text))
                    {
                        MessageBox.Show("Please fill in all customer fields.");
                        return;
                    }

                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query =
                            "INSERT INTO Customer (name, address, contactinfo) VALUES (@name, @address, @contactinfo)";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", CustomerNameTextBox.Text);
                            command.Parameters.AddWithValue("@address", CustomerAddressTextBox.Text);
                            command.Parameters.AddWithValue("@contactinfo", CustomerContactInfoTextBox.Text);
                            command.ExecuteNonQuery();
                        }

                        CustomerExpander.IsExpanded = false;

                        LoadData(); 
                    }
                }

                private void SearchCustomerButton_Click(object sender, RoutedEventArgs e)
                {
                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query = "SELECT * FROM Customer WHERE name LIKE @name";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", "%" + CustomerSearchTextBox.Text + "%");
                            using (var reader = command.ExecuteReader())
                            {
                                var dataTable = new DataTable();
                                dataTable.Load(reader);
                                dataGridCustomers.ItemsSource = dataTable.DefaultView;
                            }
                        }
                    }
                }

                private void DeleteCustomerButton_Click(object sender, RoutedEventArgs e)
                {
                    if (dataGridCustomers.SelectedItem is DataRowView selectedRow)
                    {
                        var customerId = selectedRow["id"];
                        using (var connection = new SQLiteConnection(connectionString))
                        {
                            connection.Open();
                            var query = "DELETE FROM Customer WHERE id = @id";
                            using (var command = new SQLiteCommand(query, connection))
                            {
                                command.Parameters.AddWithValue("@id", customerId);
                                command.ExecuteNonQuery();
                            }

                            LoadData();
                        }
                    }
                }
                private void AddCategoryButton_Click(object sender, RoutedEventArgs e)
                {
                    CategoryExpander.IsExpanded = true;
                }
                private void SaveCategoryButton_Click(object sender, RoutedEventArgs e)
                {
                    if (string.IsNullOrWhiteSpace(CategoryNameTextBox.Text) ||
                        string.IsNullOrWhiteSpace(CategoryDescriptionTextBox.Text))
                    {
                        MessageBox.Show("Please fill in all category fields.");
                        return;
                    }

                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query = "INSERT INTO Category (name, description) VALUES (@name, @description)";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", CategoryNameTextBox.Text);
                            command.Parameters.AddWithValue("@description", CategoryDescriptionTextBox.Text);
                            command.ExecuteNonQuery();
                        }

                        CategoryExpander.IsExpanded = false;
                        LoadData(); 
                    }
                }

                private void SearchCategoryButton_Click(object sender, RoutedEventArgs e)
                {
                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query = "SELECT * FROM Category WHERE name LIKE @name";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", "%" + CategorySearchTextBox.Text + "%");
                            using (var reader = command.ExecuteReader())
                            {
                                var dataTable = new DataTable();
                                dataTable.Load(reader);
                                dataGridCategories.ItemsSource = dataTable.DefaultView;
                            }
                        }
                    }
                }

                private void DeleteCategoryButton_Click(object sender, RoutedEventArgs e)
                {
                    if (dataGridCategories.SelectedItem is DataRowView selectedRow)
                    {
                        var categoryId = selectedRow["id"];
                        using (var connection = new SQLiteConnection(connectionString))
                        {
                            connection.Open();
                            var query = "DELETE FROM Category WHERE id = @id";
                            using (var command = new SQLiteCommand(query, connection))
                            {
                                command.Parameters.AddWithValue("@id", categoryId);
                                command.ExecuteNonQuery();
                            }

                            LoadData();
                        }
                    }
                }

                private void AddOrderButton_Click(object sender, RoutedEventArgs e)
                {
  
                    OrderExpander.IsExpanded = true;
                }

                private void SaveOrderButton_Click(object sender, RoutedEventArgs e)
                {
   
                    if (string.IsNullOrWhiteSpace(OrderDateTextBox.Text) ||
                        string.IsNullOrWhiteSpace(OrderStatusTextBox.Text) ||
                        string.IsNullOrWhiteSpace(OrderCustomerIdTextBox.Text))
                    {
                        MessageBox.Show("Please fill in all customer fields.");
                        return;
                    }

                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query =
                            "INSERT INTO Customer (date, status, customerId) VALUES (@date, @status, @customerId)";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@date", OrderDateTextBox.Text);
                            command.Parameters.AddWithValue("@status", OrderStatusTextBox.Text);
                            command.Parameters.AddWithValue("@customerId", OrderCustomerIdTextBox.Text);
                            command.ExecuteNonQuery();
                        }

                        OrderExpander.IsExpanded = false;

                        LoadData(); 
                    }
                }

                private void SearchOrderButton_Click(object sender, RoutedEventArgs e)
                {
                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query = "SELECT * FROM Order WHERE name LIKE @date";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", "%" + OrderSearchTextBox.Text + "%");
                            using (var reader = command.ExecuteReader())
                            {
                                var dataTable = new DataTable();
                                dataTable.Load(reader);
                                dataGridOrders.ItemsSource = dataTable.DefaultView;
                            }
                        }
                    }
                }

                private void DeleteOrderButton_Click(object sender, RoutedEventArgs e)
                {
                    if (dataGridOrders.SelectedItem is DataRowView selectedRow)
                    {
                        var orderId = selectedRow["id"];
                        using (var connection = new SQLiteConnection(connectionString))
                        {
                            connection.Open();
                            var query = "DELETE FROM Order WHERE id = @id";
                            using (var command = new SQLiteCommand(query, connection))
                            {
                                command.Parameters.AddWithValue("@id", orderId);
                                command.ExecuteNonQuery();
                            }

                            LoadData();
                        }
                    }
                }

                private void AddSupplierButton_Click(object sender, RoutedEventArgs e)
                {
                    SupplierExpander.IsExpanded = true;
                }

                private void SaveSupplierButton_Click(object sender, RoutedEventArgs e)
                {
                    if (string.IsNullOrWhiteSpace(SupplierNameTextBox.Text) ||
                        string.IsNullOrWhiteSpace(SupplierContactInfoTextBox.Text))
                    {
                        MessageBox.Show("Please fill in all supplier fields.");
                        return;
                    }

                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query = "INSERT INTO Supplier (name, contactinfo) VALUES (@name, @contactinfo)";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", SupplierNameTextBox.Text);
                            command.Parameters.AddWithValue("@contactinfo", SupplierContactInfoTextBox.Text);
                            command.ExecuteNonQuery();
                        }

                        SupplierExpander.IsExpanded = false;
                        LoadData(); 
                    }
                }

                private void SearchSupplierButton_Click(object sender, RoutedEventArgs e)
                {
                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query = "SELECT * FROM Supplier WHERE name LIKE @name";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", "%" + SupplierSearchTextBox.Text + "%");
                            using (var reader = command.ExecuteReader())
                            {
                                var dataTable = new DataTable();
                                dataTable.Load(reader);
                                dataGridSuppliers.ItemsSource = dataTable.DefaultView;
                            }
                        }
                    }
                }

                private void DeleteSupplierButton_Click(object sender, RoutedEventArgs e)
                {
                    if (dataGridSuppliers.SelectedItem is DataRowView selectedRow)
                    {
                        var supplierId = selectedRow["id"];
                        using (var connection = new SQLiteConnection(connectionString))
                        {
                            connection.Open();
                            var query = "DELETE FROM Supplier WHERE id = @id";
                            using (var command = new SQLiteCommand(query, connection))
                            {
                                command.Parameters.AddWithValue("@id", supplierId);
                                command.ExecuteNonQuery();
                            }

                            LoadData();
                        }
                    }
                }

                private void AddProductButton_Click(object sender, RoutedEventArgs e)
                {
                    ProductExpander.IsExpanded = true;
                }

                private void SaveProductButton_Click(object sender, RoutedEventArgs e)
                {
                    if (string.IsNullOrWhiteSpace(ProductNameTextBox.Text) ||
                        string.IsNullOrWhiteSpace(ProductPriceTextBox.Text) ||
                        string.IsNullOrWhiteSpace(ProductStockQuantityTextBox.Text) ||
                        string.IsNullOrWhiteSpace(ProductCategoryIdTextBox.Text))
                    {
                        MessageBox.Show("Please fill in all product fields.");
                        return;
                    }

                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query =
                            "INSERT INTO Product (name, price, categoryid, stockQuantity) VALUES (@name, @price, @categoryid, @stockQuantity)";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", ProductNameTextBox.Text);
                            command.Parameters.AddWithValue("@price", Convert.ToDouble(ProductPriceTextBox.Text));
                            command.Parameters.AddWithValue("@categoryid",
                                Convert.ToInt32(ProductCategoryIdTextBox.Text));
                            command.Parameters.AddWithValue("@stockQuantity",
                                Convert.ToInt32(ProductStockQuantityTextBox.Text));
                            command.ExecuteNonQuery();
                        }

                        ProductExpander.IsExpanded = false;
                        LoadData(); 
                    }
                }

                private void SearchProductButton_Click(object sender, RoutedEventArgs e)
                {
                    using (var connection = new SQLiteConnection(connectionString))
                    {
                        connection.Open();
                        var query = "SELECT * FROM Product WHERE name LIKE @name";
                        using (var command = new SQLiteCommand(query, connection))
                        {
                            command.Parameters.AddWithValue("@name", "%" + ProductSearchTextBox.Text + "%");
                            using (var reader = command.ExecuteReader())
                            {
                                var dataTable = new DataTable();
                                dataTable.Load(reader);
                                dataGridProducts.ItemsSource = dataTable.DefaultView;
                            }
                        }
                    }
                }

                private void DeleteProductButton_Click(object sender, RoutedEventArgs e)
                {
                    if (dataGridProducts.SelectedItem is DataRowView selectedRow)
                    {
                        var productId = selectedRow["id"];
                        using (var connection = new SQLiteConnection(connectionString))
                        {
                            connection.Open();
                            var query = "DELETE FROM Product WHERE id = @id";
                            using (var command = new SQLiteCommand(query, connection))
                            {
                                command.Parameters.AddWithValue("@id", productId);
                                command.ExecuteNonQuery();
                            }

                            LoadData();
                        }
                    }
                }
            }
        }